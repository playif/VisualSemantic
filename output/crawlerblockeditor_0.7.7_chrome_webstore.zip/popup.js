/**
 * Created by Tim on 2014/4/7.
 */

//var bg;
var taskList;
var currentIndex;
var currentTask;


KangoAPI.onReady(function () {

//    Kango.addMessageListener()

    kango.dispatchMessage('taskList', -1);
    kango.addMessageListener('getTaskList', function (e) {
        taskList = e.data.taskList;
        //kango.console.log(taskList);
        if (taskList.length == 0)return;
        //currentIndex = e.data.currentIndex;
        //currentTask = taskList[currentIndex];
        updateSelection();
        $('#taskSelection').val(e.data.currentIndex).change();
        setCurrentTask();
    });

    kango.addMessageListener('closePopup', function (e) {
        KangoAPI.closeWindow();
    });


    $('#taskSelection').change(function () {
        kango.dispatchMessage('saveCurrentTask', {currentTask: currentTask});
        setCurrentTask();
    });


    $('#newTaskButton').click(function () {
        kango.dispatchMessage('newTask', '');
        //bg.newTask();
        kango.dispatchMessage('taskList', taskList.length);

        //reloadTaskList();
        //$('#taskSelection').val(taskList.length - 1).change();
        //setCurrentTask();
        //reloadTask();
    });

    $('#saveTaskButton').click(function () {
        kango.dispatchMessage('updateCurrentTask', {currentTask: currentTask});
        //bg.updateTask(bg.currentTask);
    });


    checkTaskStateButton();
//    var startTaskButton = $('#startTaskButton');
//    startTaskButton.click(function () {
//        if (currentTask.state === "stop") {
//            currentTask.state = "start";
//        }
//        else {
//            currentTask.state = "stop";
//        }
//        checkTaskStateButton();
//        kango.dispatchMessage('updateCurrentTask', {currentTask: currentTask});
//        //bg.updateTask(bg.currentTask);
//    });

    var monitorTaskButton = $('#monitorTaskButton');
    monitorTaskButton.click(function () {
        kango.browser.tabs.create({url:settings.server});
        KangoAPI.closeWindow();
    });

    $('#removeTaskButton').click(function () {
        if (taskList.length <= 0) return;
        kango.dispatchMessage('removeTask', currentTask);
        remove(taskList, currentTask);
        currentTask = null;
        currentIndex = 0;
        kango.dispatchMessage('setCurrentIndex', {currentIndex: currentIndex});
        //updateSelection();
        kango.dispatchMessage('taskList', currentIndex);
    });

    var taskName = $('#taskName');
    taskName.on('input', function () {
        var name=taskName.val();
        if(name === '_') {
            alert('任務名稱不能以"_"為首！');
            taskName.val('');
            return;
        }
        currentTask.name = taskName.val();
        kango.dispatchMessage('updateCurrentTask', {currentTask: currentTask});
        //bg.updateTask(bg.currentTask);
        updateSelection();

        //kango.dispatchMessage('taskList', currentIndex);
        //reloadTaskList();
    });

    var taskRootPage = $('#taskRootPage');
    taskRootPage.on('input', function () {
        currentTask.rootURL = taskRootPage.val();
        var lastSlash = taskRootPage.val().lastIndexOf('/');
        //currentTask.baseURL = taskRootPage.val().substring(0, lastSlash) + '/';
        var parser = document.createElement('a');
        parser.href = currentTask.rootURL;

        currentTask.baseURL=parser.protocol+'//'+parser.host+'/';

        var matches = taskRootPage.val().match(/^https?\:\/\/([^\/?#]+)(?:[\/?#]|$)/i);
        //var matches = taskRootPage.val().match(/^https?\:\/\/([^\/?#]+)(?:[\/?#]|$)/i);
        var domain = matches && matches[1];

//        currentTask.homePage = domain;

        kango.dispatchMessage('updateCurrentTask', {currentTask: currentTask});
        //console.log(bg.currentTask.baseURL);
        //console.log(bg.currentTask.homePage);
        //kango.console.log(currentTask);
        //bg.updateTask(bg.currentTask);
    });

    var taskSubPage = $('#taskSubPage');
    taskSubPage.on('input', function () {
        currentTask.targetPage = taskSubPage.val();
        kango.dispatchMessage('updateCurrentTask', {currentTask: currentTask});
    });

    var taskCrawlerPage = $('#taskCrawlerPage');
    taskCrawlerPage.on('input', function () {
        currentTask.linkPage = taskCrawlerPage.val();
        kango.dispatchMessage('updateCurrentTask', {currentTask: currentTask});
    });



//    var targetPage = $('#taskCrawkerPage');
//    taskCrawkerPage.on('input', function () {
//        bg.currentTask.linkPage = taskCrawkerPage.val();
//        //bg.updateTask(bg.currentTask);
//    });
//    $('#taskWork').change(function () {
//        bg.currentTask.state = true;
//    });


    $('#newPatternButton').click(function () {
        //console.log(bg);

        kango.dispatchMessage('startBlockSelect', '');
        //startBlockSelect();
        KangoAPI.closeWindow();
//        window.close();
    });

    highlightAllBlock();
    window.onunload = function () {
        removeAllhighlight();
        kango.dispatchMessage('saveCurrentTask', {currentTask: currentTask});
        //bg.updateTask(currentTask);
    };


});

function updateSelection(){
    var select = $('#taskSelection');
    select.empty();
    var index = 0;
    for (var t in taskList) {
        var task = taskList[t];
        var option = $('<option>');
        option.val(index);
        option.text(task.name);
        option.appendTo(select);
        index++;
    }
}



function checkTaskStateButton() {
    var startTaskButton = $('#startTaskButton');
    if (currentTask && currentTask.state == "stop") {
        startTaskButton.text("啟動任務");
    }
    else {
        startTaskButton.text("關閉任務");
    }
}

function reloadPatterns() {
    var patterns = $('#blockPatterns');
    patterns.empty();

    for (var p in currentTask.fields) {
        var pat = currentTask.fields[p];
        createPatternItem(pat);
    }

    checkHead();

}

function checkHead() {
    if (currentTask.fields.length == 0) {
        $('#blockPatternHead').css('display', 'none');
    } else {
        $('#blockPatternHead').css('display', 'default');
    }
}

function setCurrentTask() {
    if (taskList.length == 0)return;

    removeAllhighlight();
    if (currentTask) {
        kango.dispatchMessage('updateCurrentTask', {currentTask: currentTask});
    }
    currentIndex = $("#taskSelection option:selected").val();
    currentTask = taskList[currentIndex];

    kango.dispatchMessage('setCurrentIndex', {currentIndex: currentIndex});
    highlightAllBlock();
    //kango.console.log(currentTask);
    reloadTask();
}


function highlightAllBlock() {
    if (!currentTask) return;
    for (var p in currentTask.fields) {
        var pat = currentTask.fields[p];
        kango.dispatchMessage('togglePattern', {pattern: pat, highlight: pat.highlight});
    }
}

function removeAllhighlight() {
    if (!currentTask) return;
    for (var p in currentTask.fields) {
        var pat = currentTask.fields[p];
        kango.dispatchMessage('hideHighlights', pat);
    }
}

//選了某個task之後，應該更新相關的表格欄位
function reloadTask() {
    if (!currentTask) return;


//    console.log("hi");
//    var val= $("#taskSelection option:selected").val();
    var taskName = $('#taskName');
    taskName.val(currentTask.name);

    var taskRootPage = $('#taskRootPage');
    taskRootPage.val(currentTask.rootURL);

    //console.log('here: ' + currentTask.targetPage);
    var taskSubPage = $('#taskSubPage');
    taskSubPage.val(currentTask.targetPage);

    var taskCrawlerPage = $('#taskCrawlerPage');
    taskCrawlerPage.val(currentTask.linkPage);

    reloadPatterns();

    //console.log(currentIndex);
}

// 新創一個pattern 的條目
function createPatternItem(pat) {
    var patterns = $('#blockPatterns');
    //fields.empty();

    var item = $('<tr>');
    //item.css('height', '500px');

    var checkBox = $('<input>');
    checkBox.prop('type', 'checkbox');
    checkBox.prop('checked', pat.highlight);
    checkBox.change(function () {
        kango.dispatchMessage('togglePattern', {pattern: pat, highlight: checkBox.is(':checked')});
        //bg.togglePattern(pat, checkBox.is(':checked'));

        //console.log(checkBox.is(':checked'));
    });
    item.append(createCell(checkBox));

    var colorBox = $('<input>');
    colorBox.val(pat.color);

    item.append(createCell(colorBox));
    colorBox.colorPicker();
    colorBox.change(function () {
        pat.color = colorBox.val();
        if (pat.highlight == true) {
            kango.dispatchMessage('showHighlights', pat);
            //bg.showHighlights(pat);
        }
        //bg.updateTask(bg.currentTask);
    });


    var patternName = $('<input>');
    patternName.val(pat.name);
    patternName.on('input', function () {
        pat.name = patternName.val();
        //bg.updateTask(bg.currentTask);
        //$(this).replaceWith('<input type="text"/>').focus();
    });
    patternName.attr('placeholder','請輸入區塊名稱。');
    //colorBox.prop('type','checkbox');
    item.append(createCell(patternName));

    var pattern = $('<input>');
    pattern.val(pat.path);
    pattern.css({width: '150px'});
    pattern.addClass('patternText');
    pattern.on('input', function () {
        pat.path = pattern.val();
        //bg.updateTask(bg.currentTask);
        //$(this).replaceWith('<input type="text"/>').focus();
    });
    //colorBox.prop('type','checkbox');
    item.append(createCell(pattern).css({width: '150px'}));

    item.append(createCell(createCheckBox(pat, 'saveText')));
    item.append(createCell(createCheckBox(pat, 'saveLink')));
    item.append(createCell(createCheckBox(pat, 'saveResources')));
    item.append(createCell(createCheckBox(pat, 'saveHTML')));

    var deleteButton = $('<button>');
    deleteButton.text('刪除');
    deleteButton.click(function () {
        item.remove();
        remove(currentTask.fields, pat);
        kango.dispatchMessage('saveCurrentTask', currentTask);
        //bg.updateTask(bg.currentTask);
        checkHead();
        kango.dispatchMessage('hideHighlights', pat);
        //bg.hideHighlights(pat);
    });
    deleteButton.addClass('btn-xs btn-danger');
    item.append(createCell(deleteButton));

    item.addClass('patternItem');
    item.appendTo(patterns);
}

// 創一個cell (在創pattern時使用)
function createCell(content) {
    var cell = $('<td>');
    cell.append(content);
    return cell;
}

function createCheckBox(pat, prop) {
    var checkBox = $('<input>');
    checkBox.prop('type', 'checkbox');
    checkBox.prop('checked', pat[prop]);
    checkBox.change(function () {
        pat[prop] = checkBox.is(':checked');
        console.log(checkBox.is(':checked'));
        //bg.updateTask(bg.currentTask);
    });
    return checkBox;
}

function remove(arr, obj) {
    for (var i = arr.length; i--;) {
        if (arr[i] === obj) {
            arr.splice(i, 1);
        }
    }
}





