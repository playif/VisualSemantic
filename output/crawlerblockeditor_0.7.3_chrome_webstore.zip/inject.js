// ==UserScript==
// @name inject
// @include http://*
// @include https://*
// @require js/jquery-2.1.0.min.js
// @require js/jquery.livequery.min.js
// ==/UserScript==

/**
 * Created by Tim on 2014/4/6.
 */
/*, "background", "notifications", "unlimitedStorage", "webRequest", "webRequestBlocking"*/

//全域變數的宣告。
var root = $('body');
//var port = chrome.runtime.connect();
var queryString = 'div,h1,a,table';
var currentHighlights = [];

var msg = $('<label>');
var cancelButton = $('<button>');
var border = $('<label>');

var isSelecting = false;

//TODO 初始化的宣告，但是有些網站一直讀不完，會導致程式無法run。
//root.ready(initial);
function initial() {
    //port.postMessage($('title').text());

    $('document').ready(function () {
        //port.postMessage('fin');
    });

    msg.css({position: 'fixed', top: '0px', left: '0px', zIndex: 10000, backgroundColor: 'Yellow'});
//    border.css({position: 'absolute', top: '50px', left: '0px', zIndex: 10000,border:'1px Red solid'});
//    msg.text('');
    root.append(msg);
//    root.append(border);
//    port.onMessage.addListener(function (msg) {
//        console.log(msg);
//    });

    cancelButton.css({position: 'fixed', top: '0px', right: '0px', zIndex: 10001});
    cancelButton.text('取消');


    initDoms();
}
initial();


kango.addMessageListener('startBlockSelect', function (e) {
    //alert('Background script says: ' + e.data);
    //kango.console.log("here");
    startSelect();

});

//開始選擇區塊
function startSelect() {
    isSelecting = true;
    root.append(cancelButton);
    cancelButton.click(function () {
        endSelect();
    });

    //SetupDoms();
}

//結束選擇區塊
function endSelect() {
    isSelecting = false;
    updateBorder();
    msg.text('');
    cancelButton.remove();
//    cancelButton.click(function(){
//        endSelect();
//    });
    currentHighlights = [];
}

function initDoms() {

    $(queryString).livequery(function () {
        if (this.isSet) {
            return;
        }
        this.isSet = true;
//        var me=$(this);
        $(this).hover(function (e) {
            if (!isSelecting) {
                return;
            }

            var me = $(this);
            this.borderTmp = me.css('box-shadow');
            this.path = getDomPath(this);
            currentHighlights.push(this);

            updateBorder();

            //e.stopPropagation();


        }, function (e) {
            if (!isSelecting) {
                return;
            }
            var me = $(this);
            me.css({boxShadow: this.borderTmp});

            remove(currentHighlights, this);
            updateBorder();
        });

        $(this).click(function (e) {
            if (!isSelecting) {
                return;
            }

            var doms = $(getDomPath(this));
            doms.css({ transition: 'background 0s', backgroundColor: '#FFccFF'});
            setTimeout(function () {
                doms.css({transition: 'background 1s', backgroundColor: 'none'});
            }, 500);


            //    doms.each(function () {
            //        var me = this;
            //        port.postMessage(me.innerText);
            //    });

            //port.postMessage({type: 'addPath', path: getDomPath(this)});
            kango.dispatchMessage('addPath', {path: getDomPath(this)});

            endSelect();

            e.preventDefault();
            e.stopPropagation();
        });
    });
}


//更新選擇的邊框
function updateBorder() {
    var max = 0;
    var mc;
    for (var i in currentHighlights) {
        var c = currentHighlights[i];
        if (c.path.length > max) {
            max = c.path.length;
            mc = c;
        }
        var q = $(c);
        q.css({boxShadow: c.borderTmp});
    }

    //console.log(currentHighlights);
    if (isSelecting) {
        if (mc) {
            var me = $(mc);
            me.css({boxShadow: '0px 0px 10px 10px #FFbbFF, 0 0 10px #FFbb00 inset'});
            msg.text(mc.path);
            var offset = me.offset();
            //kango.console.log(me.offset());
            //border.css({left: offset.left, top: offset.top});
            //border.text('this?');
            //border.css({width: me.width(), height: '1px'});
        }
    }

}


kango.addMessageListener('showHighlights', function (e) {
    var pat = e.data;
    showHighlights(pat.path, pat.color);
});

kango.addMessageListener('hideHighlights', function (e) {
    var pat = e.data;
    hideHighlights(pat.path);
});

//更新 高亮顯示
function showHighlights(path, color) {
    //console.log(path);
    $(path).css({transition: 'background 1s', backgroundColor: color});
}

function hideHighlights(path) {
    //console.log(path);
    $(path).css({transition: 'background 1s', backgroundColor: 'none'});
}

function remove(arr, element) {
    var idx = arr.indexOf(element);
    if (idx > -1) {
        arr.splice(idx, 1);
    }
}


//更新 高亮顯示
function showHighlightsByRegex(path, color, pattern) {
    var regex = new RegExp(pattern);
    //console.log(path);
    $(path).each(function (e) {
        var me = $(this);
        if (regex.test(me.prop('href'))) {
            me.css({transition: 'background 1s', backgroundColor: color});
        }
    });
}


function getDomPath(element) {
    var path = '';
    for (; element && element.nodeType == 1 && element.tagName != "html"; element = element.parentNode) {
        //var inner = $(element).children().length == 0 ? $(element).text() : '';
        var eleSelector = element.tagName.toLowerCase();
        if (element.id && !element.id.match(/\d/)) {

            //console.log(element.id);
            //console.log(element.id);
            try {
                var testID = "#" + element.id;
                if ($(testID).length != 0) {
                    eleSelector = testID;
                }
                //console.log(testID);
            }
            catch (e) {
                //console.log(e);
            }
        }

        //console.log(eleSelector);
//        +
//            ((inner.length > 0) ? ':contains(\'' + inner + '\')' : '');
        if (element.className) {
            var goodClasses = [];
            var classNames = element.className.split(" ");
            for (var i in classNames) {
                var cn = classNames[i];
                if (cn != "" && !cn.match(/\d/)) {
                    goodClasses.push(cn);
                }
            }

            var testClass = eleSelector + "." + goodClasses.join('.');
            //element.className.trim().replace(/ ./g, '.');
            try {
                if ($(testClass).length != 0) {
                    eleSelector = testClass;
                }
            }
            catch (e) {

            }

            //console.log(element.className);
            //eleSelector += "." + element.className.trim().replace(/ ./g, '.');
        }

        path = ' ' + eleSelector + path;
    }
    //console.log(path);
    //console.log($(testID).length);

    if (path.indexOf("#") > -1) {
        var tokens = path.split('#');
        path = '#' + tokens[tokens.length - 1];
    }
    //console.log('path: ' + path);

    return path;
}

function createPreviewWindow() {
    $("<div>").css();


}
