
function getOrDefault(name,defaultValue){
    var value=kango.storage.getItem(name);
    if(value === null){
        return defaultValue;
    }
    return value;
}

function bindProperity(obj,name,defaultValue){
    Object.defineProperty(obj, name, {
        set: function(value){
            kango.storage.setItem(name,value);
            kango.console.log(value);
        },
        get: function(){
            return getOrDefault(name,defaultValue);
        }
    });
}

var settings={};
//bindProperity(settings,'server','http://220.134.108.206:8002/api/');
bindProperity(settings,'server','http://localhost');

bindProperity(settings,'color','#FFccFF');

bindProperity(settings,'offline',false);

