﻿// ==UserScript==
// @name Test
// @require storageServices.js
// ==/UserScript==

function BlockEditor() {
    var me = this;
//    kango.ui.browserButton.addEventListener(kango.ui.browserButton.event.COMMAND, function () {
//
//
//    });

    Object.defineProperty(me, 'storageService', {
        get: function () {
            if (settings.offline) {
                return LocalStorageService;
            }
            return RemoteStorageService;
        }
    });

    kango.addMessageListener('taskList', function (e) {
        if (e.data != -1 && me.taskList.length != 0) {
            me.currentIndex = e.data;
        }
        me.storageService.read(function (list) {
            me.taskList = list;

            for (var i = 0; i < me.taskList.length; i++) {
                if (!me.taskList[i].fields) {
                    me.taskList[i].fields = [];
                }
            }

            kango.dispatchMessage('getTaskList', {taskList: me.taskList, currentIndex: me.currentIndex});
        });

    });

    kango.addMessageListener('setCurrentIndex', function (e) {
        me.currentIndex = e.data.currentIndex;
    });

    kango.addMessageListener('updateCurrentTask', function (e) {
        if (!e.data.currentTask) return;
        me.taskList[me.currentIndex] = e.data.currentTask;
        //me.updateTask(me.taskList[me.currentIndex]);
    });

    kango.addMessageListener('saveCurrentTask', function (e) {
        if (!e.data.currentTask) return;
        me.taskList[me.currentIndex] = e.data.currentTask;
        me.updateTask(me.taskList[me.currentIndex]);
    });

    kango.addMessageListener('togglePattern', function (e) {
        var pat = e.data.pattern;
        var highlight = e.data.highlight;
        me.togglePattern(pat, highlight);
    });

    kango.addMessageListener('showHighlights', function (e) {
        me.showHighlights(e.data);
    });

    kango.addMessageListener('hideHighlights', function (e) {
        me.hideHighlights(e.data);
    });

    kango.addMessageListener('newTask', function (e) {
        me.newTask();
    });

    kango.addMessageListener('removeTask', function (e) {
        me.removeTask(e.data);
    });

    kango.addMessageListener('startBlockSelect', function (e) {
        kango.browser.tabs.getCurrent(function (tab) {
            // tab is KangoBrowserTab object
            //kango.console.log(tab);
            tab.dispatchMessage('startBlockSelect', '');
        });
    });

    kango.addMessageListener('addPath', function (e) {
        me.taskList[me.currentIndex].fields.push({
            path: e.data.path,
            highlight: true,
            //task: 'pattern ' + currentTask.fields.length,
            color: settings.color
        });
        kango.console.log(e);
        me.updateTask(me.taskList[me.currentIndex]);
    });


//    kango.addMessageListener('getServer', function (e) {
//        kango.dispatchMessage('server', settings.server);
//    });
//
//    kango.addMessageListener('setServer', function (e) {
//        settings.server = e.data;
//    });


//
//    // 和當前頁面互動的訊息傳遞。
//    chrome.runtime.onConnect.addListener(function (p) {
//        var port = p;
//
//        //console.log(port.task == "knockknock");
//        var tab = port.sender.tab;
//
//        port.onMessage.addListener(function (data) {
//            var type = data.type;
//            console.log(type);
//            //port.postMessage({ack: "200"});
//
//            switch (type) {
//                case 'addPath':
//                    currentTask.fields.push({
//                        path: data.path,
//                        highlight: true,
//                        //task: 'pattern ' + currentTask.fields.length,
//                        color: '#FFccFF'
//                    });
//                    updateTask(currentTask);
//                    //chrome.tabs.create({url:"popup.html"});
//                    break;
//                case
//                'start'
//                :
//                    port();
//                    //chrome.tabs.remove(tab.id);
//                    break;
//                case
//                'fin'
//                :
//                    var tid = data.tid;
//                    releaseCrawlerTab();
//                    //chrome.tabs.remove(tid);
//
//                    break;
//                default :
//                    break;
//            }
//        });
//    });

//    me.loadTasks();
}

BlockEditor.prototype = {

    taskList: [],
//    currentTask: '',
    currentIndex: 0,
    taskNum: 'task_number',
//    storageService: LocalStorageService,

//    loadTasks: function () {
//        var me = this;
//        me.storageService.read(function (list) {
//            me.taskList = list;
//
//            for (var i = 0; i < me.taskList.length; i++) {
//                if (!me.taskList[i].fields) {
//                    me.taskList[i].fields = [];
//                }
//            }
//
//        })
//    },

    //按下新任務後馬上執行，並取得taskID。
    newTask: function () {
        var me = this;
        var task = new Task();
        task.name = 'task';
        me.storageService.create(task, function (taskID) {
            //console.log(taskID);
            task.id = taskID;

        });

        //需同時新增taskList 裡面的task
        me.taskList.push(task);
    },

    //根據task 的ID 移除 該task。
    removeTask: function (task) {
        var me = this;
        //需同時移除taskList 裡面的task
        remove(me.taskList, task);
        me.storageService.remove(task);

        //console.log('remove');
    },

    //根據task 的ID 更新該task。
    updateTask: function (task) {
        var me = this;
        me.storageService.update(task);
    },



    // 開始進行選擇區塊(當user 按下新增區塊後執行)，對應的func 請參考inject.js。
//    startBlockSelect: function () {
//        chrome.tabs.executeScript({code: 'startSelect();'});
//    },


    togglePattern: function (pattern, highlight) {
        var me = this;
        if (!highlight) {
            pattern.highlight = false;
            me.hideHighlights(pattern);
        }
        else {
            pattern.highlight = true;
            me.showHighlights(pattern);
        }
    },

    showHighlights: function (pattern) {
        kango.browser.tabs.getCurrent(function (tab) {
            // tab is KangoBrowserTab object
            //kango.console.log(tab);
            tab.dispatchMessage('showHighlights', pattern);
        });
    },

    hideHighlights: function (pattern) {
        kango.browser.tabs.getCurrent(function (tab) {
            // tab is KangoBrowserTab object
            //kango.console.log(tab);
            tab.dispatchMessage('hideHighlights', pattern);
        });
    }

//
//    _onCommand: function () {
//        kango.browser.tabs.create({url: 'http://kangoextensions.com/'});
//    }
};


function Task() {
    //var task = {};
    this.id = "";
    this.name = "";
//    this.urls = {};
//    this.finishedURLs = {};
    this.fields = [];
//task.sourcePatterns = {};
    this.state = 'stop';

    this.baseURL = "";
    this.rootURL = "";

//    this.homePage = "";
    this.linkPage = "";
    this.targetPage = "";
    //return task;
}

function remove(arr, obj) {
    for (var i = arr.length; i--;) {
        if (arr[i] === obj) {
            arr.splice(i, 1);
        }
    }
}

function size(obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
}

var bg = new BlockEditor();

