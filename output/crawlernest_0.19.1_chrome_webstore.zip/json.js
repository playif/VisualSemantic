[
    {"id": "1", "task": "Google", "urls": {}, "finishedURLs": {}, "fields": [
        {"path": " html #gsr.srp.vsh #viewport.ctr-p #main.content #cnt div.mw #sfcnt #sform #tsf div.tsf-p #logocont.nojsv h1 #logo", "highlight": true, "task": "logo", "color": "#99cc00"}
    ], "state": "idle", "rootURL": "https://www.google.com.tw/", "subPage": "https://www.google.com.tw/links"},
    {"id": "2", "task": "task 2", "urls": {}, "finishedURLs": {}, "fields": [], "state": "idle"},
    {"id": "5", "task": "task 5", "urls": {}, "finishedURLs": {}, "fields": [], "state": "idle"}
]